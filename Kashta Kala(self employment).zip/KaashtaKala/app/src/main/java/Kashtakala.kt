package com.example.kaashtakala

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Carpenter Details
        val carpenterName = "Ravi"
        val furnitureDesign = "Modern Sofa"

        // Material Calculation
        val length = 8
        val width = 4
        val woodPrice = 150

        val woodNeeded = length * width
        val totalCost = woodNeeded * woodPrice

        // Design Catalog
        val designCatalog = """
            
            DESIGN CATALOG
            • Modern Sofa
            • Wooden Bed
            • Dining Table
            • TV Cabinet
            • Office Chair
        """.trimIndent()

        // Full Text Output
        val text = """
            KASHTA-KALA CARPENTER APP
            
            Carpenter Name: $carpenterName
            
            Furniture Design: $furnitureDesign
            
            Wood Needed: $woodNeeded sq.ft
            
            Estimated Cost: ₹$totalCost
            
            $designCatalog
            
            
        """.trimIndent()

        // Display on Screen
        val textView = TextView(this)
        textView.text = text
        textView.textSize = 18f

        setContentView(textView)
    }
}
